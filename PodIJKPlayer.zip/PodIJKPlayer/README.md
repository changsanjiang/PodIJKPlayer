# PodIJKPlayer

[![CI Status](https://img.shields.io/travis/changsanjiang/PodIJKPlayer.svg?style=flat)](https://travis-ci.org/changsanjiang/PodIJKPlayer)
[![Version](https://img.shields.io/cocoapods/v/PodIJKPlayer.svg?style=flat)](https://cocoapods.org/pods/PodIJKPlayer)
[![License](https://img.shields.io/cocoapods/l/PodIJKPlayer.svg?style=flat)](https://cocoapods.org/pods/PodIJKPlayer)
[![Platform](https://img.shields.io/cocoapods/p/PodIJKPlayer.svg?style=flat)](https://cocoapods.org/pods/PodIJKPlayer)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

PodIJKPlayer is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'PodIJKPlayer'
```

## Author

changsanjiang, changsanjiang@gmail.com

## License

PodIJKPlayer is available under the MIT license. See the LICENSE file for more info.
